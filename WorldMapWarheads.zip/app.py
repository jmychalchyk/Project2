# Importing necessary libraries

import pandas as pd
from titlecase import titlecase

from flask import (
	Flask,
	render_template,
	jsonify,
	request)

from flask_sqlalchemy import SQLAlchemy

from sqlalchemy.sql import func

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///static/db/warheads.sqlite"

db = SQLAlchemy(app)

class Warhead(db.Model):
	__tablename__ = 'warheads_inventories'

	Id = db.Column(db.Integer, primary_key=True)
	Country = db.Column(db.String)
	Country_code = db.Column(db.String)
	Year = db.Column(db.Integer)
	Warheads_count = db.Column(db.Integer)

	def __repr__(self):
		return '<Warhead %r>' % (self.Country)

class CountryDetail(db.Model):
    __tablename__ = 'nuclearBases2017'

    Id = db.Column(db.Integer, primary_key=True)
    countries = db.Column(db.String)
    Baselocation = db.Column(db.String)
    Region = db.Column(db.String)
    Latitude = db.Column(db.Integer)
    Longitude = db.Column(db.Integer)
    Weaponsystem = db.Column(db.String)
    Remarks = db.Column(db.String)

    def __repr__(self):
        return '<CountryDetail %r>' % (self.countries)

@app.before_first_request
def setup():
	db.create_all()

@app.route("/")
def home():
	return render_template("index.html")

@app.route("/global")
def global_data():
	results = db.session.query(Warhead.Country,Warhead.Year,func.sum(Warhead.Warheads_count).label('warhead_count')).group_by(Warhead.Year).all()
	trace9 = {}
	for result in results:
		trace9["x"] = [int(result[1]) for result in results]
		trace9["y"] = [int(result[2]) for result in results]
		trace9["name"] = "Global"
		trace9["marker"] = {"color":"#116466"}
		trace9["type"] = "bar"
	return jsonify(trace9) 


@app.route("/<v_countryRoute>")
def f_dynamicData(v_countryRoute):
	results = db.session.query(Warhead.Year, func.sum(Warhead.Warheads_count)).filter(Warhead.Country == titlecase(v_countryRoute)).group_by(Warhead.Country, Warhead.Year).all()
	trace = {}
	for result in results:
		trace["x"] = [int(result[0]) for result in results]
		trace["y"] = [int(result[1]) for result in results]
		trace["name"] = titlecase(v_countryRoute)
		trace["marker"] = {"color":"#116466"}
		trace["type"] = "bar"
	return jsonify(trace)

@app.route("/detail/<v_countryDetail>")
def f_dynamicDetail(v_countryDetail):
	results = db.session.query(
	   CountryDetail.countries,
       CountryDetail.Baselocation,
       CountryDetail.Region,
       CountryDetail.Latitude,
       CountryDetail.Longitude,
       CountryDetail.Weaponsystem,
       CountryDetail.Remarks).filter(CountryDetail.countries == titlecase(v_countryDetail)).all()
	v_detail = {}
	for result in results:
		v_detail["Country"] = titlecase(v_countryDetail)
		v_detail["BaseLocation"] = [result[1] for result in results]
		v_detail["Region"] = [result[2] for result in results]
		v_detail["WeaponSystem"] = [result[5] for result in results]
		v_detail["Remarks"] = [result[6] for result in results]
		v_detail["lat"] = [result[3] for result in results]
		v_detail["lon"] = [result[4] for result in results]
	return jsonify(v_detail)

if __name__ == "__main__":
	app.run(debug=True)

