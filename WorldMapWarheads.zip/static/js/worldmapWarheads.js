var v_data =[];

var map = L.map("map-id", { center: [29.3859793,-40.7761755],doubleClickZoom: false, zoom: 2 });
 
  // Adding tile layer
  L.tileLayer("https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}", {
            attribution: "Map data &copy; <a href=\"https://www.openstreetmap.org/\">OpenStreetMap</a> contributors, <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">CC-BY-SA</a>, Imagery © <a href=\"https://www.mapbox.com/\">Mapbox</a>",
            maxZoom: 18,
            id: "mapbox.dark",
            accessToken: v_mapboxAPI
  }).addTo(map);

var link ="../static/db/countryBorders.geojson"

const  c_countries = ['Belgium','China','France','Germany','India','Italy','Israel','Netherlands','Pakistan','Russia','Turkey','United Kingdom','United States of America'];

function f_compare(ADMIN){
        var x = false;
         c_countries.forEach(function(country){ if(ADMIN == country){x = true;} else { }}); return x; };
                 
d3.json(link, function(data) {
        L.geoJson(data,{
            filter: function(feature, layer) { if(f_compare(feature.properties.ADMIN) ){ return true;} else {}},
            style: function(feature) { return { color: v_white, fillColor: v_maroon, fillOpacity: 0.3, weight: 1.5};},
            onEachFeature: function (feature, featureLayer) {            
                featureLayer.on('click', function () {
  
                f_getDetail(feature.properties.ADMIN);});
              }
            }).addTo(map);});
            
function f_clean(){
    d3.select("tbody").selectAll("tr").remove();
     v_data = []; 
}

function f_getDetail(route) {
    d3.json(`/detail/${route}`, 
    function (data) {
    var v_country = data.Country;
    var v_baseLocation = data.BaseLocation;
    var v_region = data.Region;
    var v_remarks = data.Remarks;
    var v_weapons = data.WeaponSystem;
    v_baseLocation.forEach(function(x,i){
    
    v_data.push( {
        "country":v_country,
        "base":x,
        "region":v_region[i],
        "remarks":v_remarks[i],
        "weapon":v_weapons[i]
    });
    } ); 
});

d3.select("tbody")
.selectAll("tr")
.data(v_data)
.enter()
.append("tr")
.html(function(d) {
    return `<td>${d.country}</td>
    <td>${d.base}</td>
    <td>${d.region}</td>
    <td>${d.remarks}</td>
    <td>${d.weapon}</td>`;});
};

       
