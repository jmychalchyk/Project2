v_mapboxAPI = 'pk.eyJ1Ijoiam15Y2hhbGNoeWsiLCJhIjoiY2pwNWtkMjRrMDk3NzNycWpjb3VoY3NjbiJ9.-wAxVoAy_SEJu6uH_wB72w'
v_maroon = '#935347'
v_darkGreen = '#334431'
v_brightYellow = '#f2b632'
v_white = '#ffffff'
v_darkBrown = '#262216'
v_lighterBrown = '#49412c'
v_khaki = '#97743a'
v_tan = '#b0a18e'
v_backColor = '#ede9ce'



